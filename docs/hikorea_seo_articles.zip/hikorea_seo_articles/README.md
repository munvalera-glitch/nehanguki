# HiKorea Forms SEO Articles

Готовый пакет Markdown-файлов для preview-раздела статей.

## Файлы

- `id-card-renewal-korea.md`
- `address-change-korea.md`
- `lost-id-card-korea.md`
- `first-id-card-korea.md`
- `hikorea-password-recovery.md`
- `immigration-office-appointment-korea.md`
- `articles.manifest.json`

## Задача для агента

Создать preview-раздел `/articles` и отдельные страницы статей по `slug` из frontmatter.

Каждая статья должна использовать:
- `title`
- `description`
- `slug`
- `canonical`
- `ogTitle`
- `ogDescription`
- `publishedAt`

## URL

- `/articles/id-card-renewal-korea`
- `/articles/address-change-korea`
- `/articles/lost-id-card-korea`
- `/articles/first-id-card-korea`
- `/articles/hikorea-password-recovery`
- `/articles/immigration-office-appointment-korea`

## Важно

Preview закрыть от индексации до утверждения дизайна:
- `robots.txt`
- или `<meta name="robots" content="noindex,nofollow">`

Не менять OCR, PDF generation, оплату, Google Login, корзину, My Page, админку и текущие формы.
